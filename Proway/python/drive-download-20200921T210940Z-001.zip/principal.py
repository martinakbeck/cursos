import funcoes
print('----------- Banco Proway -----------')
login = int(input('Número de conta: '))
print(funcoes.verifica_login(login))
print(funcoes.mostra_menu())
    

        

          
